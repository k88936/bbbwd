Hey there, thanks for purchasing! If you have some problems 
or petitions contact me by:
Instagram: @underpixelarted
Gmail: anders0nfern4ndez@gmail.com
Twitter: @Paradox1821
thank you!